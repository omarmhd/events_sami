<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .ticket {
            border: 1px solid #ddd;
            padding: 20px;
            margin-bottom: 20px;
        }
        .ticket img {
            display: block;
            margin: 10px 0;
            max-width: 100%;
        }
        .details {
            margin-top: 10px;
        }
    </style>
</head>
<body>
<h1>Thank you <?php echo e($employee->name); ?> for your ticket</h1>
<img src="<?php echo e(asset("assets/header.jpg")); ?>" class="event_image" alt="SAMI-AEC 2024 Picnic  | رحلة الشركة السنوية 2024">

<p>Thank you for the order you recently placed for tickets to the event: SAMI-AEC 2025 Picnic | رحلة الشركة السنوية 2025</p>

<?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="ticket">
        <h3>Ticket <?php echo e($loop->iteration); ?> of <?php echo e(count($tickets)); ?></h3>
        <div class="details">
            <p><strong>Ticket Code:</strong> EV<?php echo e($ticket->id); ?></p>
            <p><strong>Ticket Type:</strong> <?php echo e($ticket->is_children === 'yes' ? 'Child' : 'Employee'); ?></p>
            <p><strong>Event Code:</strong> <?php echo e($event->name); ?></p>
            <p><strong>Location  :</strong> <?php echo e($event->address); ?></p>
            <p><strong>Date & Time:</strong> <?php echo e($event->date); ?> <?php echo e($event->from_time); ?> - <?php echo e($event->to_time); ?></p>
        </div>



        <!-- Use Content-ID to display the image in the email body -->
        <img width="180"  height="180" src="<?php echo e($message->embed(\Illuminate\Support\Facades\Storage::disk('public')->path("qr_codess/".$ticket->barcode))); ?>" alt="صورة ترحيبية">


    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<p>Thank you!</p>
</body>
</html>
<?php /**PATH D:\2025\sami-events\resources\views/email.blade.php ENDPATH**/ ?>