
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <title>QR Code Scanner /   </title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 0;
            height: 100vh;
            box-sizing: border-box;
            text-align: center;
        }

        .container {
            width: 100%;
            max-width: 500px;
            margin: 5px;
        }



        .section {
            background-color: #ffffff;
            padding: 30px 20px;
            border: 1.5px solid #b2b2b2;
            border-radius: 0.25em;
            box-shadow: 0 20px 25px rgba(0, 0, 0, 0.25);
        }

        #my-qr-reader {
            margin-bottom: 20px;
            border: 1.5px solid #b2b2b2 !important;
            border-radius: 8px;
        }

        button {
            padding: 10px 20px;
            border: 1px solid #b2b2b2;
            outline: none;
            border-radius: 0.25em;
            color: white;
            font-size: 15px;
            cursor: pointer;
            margin-top: 15px;
            background-color: gray;
            transition: 0.3s background-color;
        }

        button.active {
            background-color: #008000;
            cursor: pointer;
        }

        button:hover.active {
            background-color: #005500;
        }

        video {
            width: 100% !important;
            border: 1px solid #b2b2b2 !important;
            border-radius: 0.25em;
        }

        #result {
            margin-top: 15px;
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }
    </style>
</head>

<body>

<a class="" title="go to dashboard" style="background: #cecece;padding: 10px" href="<?php echo e(route("dashboard.index")); ?>"><li class="fa fa-home"></li></a>
<div class="container">
    <h1>Scan QR Code for Attendance</h1>

    <div class="section">
        <div id="my-qr-reader"></div>
        <button id="attendance-btn" disabled>Register Attendance</button>
        <div id="result">QR code has not been scanned yet</div>
    </div>
</div>
<script src="https://unpkg.com/html5-qrcode"></script>
<script>
    let html5QrcodeScanner;
    let qrData = "";
    const attendanceBtn = document.getElementById("attendance-btn");
    const resultDiv = document.getElementById("result");

    function startScanner() {
        html5QrcodeScanner = new Html5Qrcode("my-qr-reader");

        // تشغيل المسح
        html5QrcodeScanner.start(
            { facingMode: "environment" }, // الكاميرا الخلفية
            {
                fps: 10, // عدد الإطارات في الثانية
                qrbox: { width: 250, height: 250 }, // حجم الإطار
            },
            onScanSuccess,
            onScanFailure
        ).catch((err) => {
            console.error("Error starting scanner:", err);
        });
    }

    // عند مسح QR بنجاح
    function onScanSuccess(decodedText, decodedResult) {
        qrData = decodedText;
        attendanceBtn.disabled = false;
        attendanceBtn.classList.add("active");
        resultDiv.textContent = `QR code scanned: VE${qrData}`;

        html5QrcodeScanner.stop().then(() => {
            console.log("Scanner stopped after success.");
        }).catch((err) => {
            console.error("Error stopping scanner:", err);
        });
    }


    function onScanFailure(error) {
        console.error(`QR Code Scan Error: ${error}`);
    }


    attendanceBtn.addEventListener("click", function () {
        if (!qrData) return;


        $.ajax({
            url: "<?php echo e(route('checked_in')); ?>", // Route URL
            method: "GET", // Request method
            data: {
                qrData: qrData // Data sent to the server
            },
            success: function (data) {
                if (data.success) {
                    $("#result").text("Attendance has been successfully recorded!");
                } else {
                    $("#result").text("An error occurred while recording attendance.");
                }
            },
            error: function (xhr, status, error) {
                console.error("Error:", error);
                $("#result").text("An error occurred during the request.");
            }
        });



        qrData = "";
        attendanceBtn.disabled = true;
        attendanceBtn.classList.remove("active");
        startScanner();
    });

    document.addEventListener("DOMContentLoaded", startScanner);
</script>
</body>

</html>
<?php /**PATH D:\2024\ticket\tickts\tickets\resources\views/admin/qr.blade.php ENDPATH**/ ?>