<!DOCTYPE html>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">

    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('assets')); ?>/style.css">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('assets')); ?>/event-page-description.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets')); ?>/font-faces.css" media="all">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('assets')); ?>/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('assets')); ?>/brands.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .step {
            display: none;
        }
        .step.active {
            display: block;
        }
    </style>



    <style type="text/css">
        @font-face {
            font-weight: 400;
            font-style:  normal;
            font-family: circular;
        }

        @font-face {
            font-weight: 700;
            font-style:  normal;
            font-family: circular;

        }
        body {
            margin: 0;
            padding: 0;
            width: 100%;
            overflow-x: hidden; /* إخفاء أي تجاوز أفقي */
        }

        .container {
            max-width: 100%;
            width: 100%;
            margin: 0 auto;
        }

    </style></head>
<body class="event_listing beta beta_v3" >






<style type="text/css" id="custom_css" class="custom_css">

    body { background-color: /*background_color*/#F5F5F6/*background_color*/;
        font-family: /*font*/'Open Sans', sans-serif/*font*/; }

    * {
        outline-offset: 4px;
    }
    body.listings { background-color: /*page_color*/#FFFFFF/*page_color*/; }
    body.listings div.store a.btn.btn_outline {
        color: /*header_text_color*/#000000/*header_text_color*/ !important;
        border-color: /*header_text_color*/#000000/*header_text_color*/ !important;
    }
    header { background-color: /*header_color*/#FFFFFF/*header_color*/; }
    body header h1, body.page_not_found header h1, header#global_large_header .text_logo { color: /*header_text_color*/#000000/*header_text_color*/; }
    footer { background-color: /*page_color*/#FFFFFF/*page_color*/; }
    body, footer p, footer p a { color: /*page_text_color*/#4A4A4A/*page_text_color*/; }
    #ticket_tailor_footer_logo g { fill: /*page_text_color*/#4A4A4A/*page_text_color*/; }

    div.row { background-color: /*page_color*/#FFFFFF/*page_color*/; }
    div.row.event_listing a  { color: /*page_text_color*/#4A4A4A/*page_text_color*/; }
    div.row.event_listing div.event_image { background-color: /*page_text_color*/#4A4A4A10/*page_text_color*/;  }
    div.row.event_listing div.event_image svg g#img-event-empty { fill: /*page_text_color*/#4A4A4A/*page_text_color*/;  }

    @media (max-width: 639px) {
        div.row { border-bottom: 1px solid /*page_text_color*/#4A4A4A33/*page_text_color*/; }
    }

    footer.event_page_footer { border-top: 1px solid /*page_text_color*/#4A4A4A33/*page_text_color*/; }

    div.row.content svg.padlock g { fill: /*page_text_color*/#4A4A4A/*page_text_color*/; }

    div.row.event_listing.no_events p { color: /*page_text_color*/#4A4A4A/*page_text_color*/; }

    .btn { background-color: /*button_color*/#46AA32/*button_color*/ !important;
        color: /*button_text_color*/#FFFFFF/*button_text_color*/ !important; }
    .btn.btn_outline { background-color: transparent !important; border-color: /*page_text_color*/#4A4A4A/*page_text_color*/ !important;
        color: /*page_text_color*/#4A4A4A/*page_text_color*/ !important; }

    a { color: /*page_text_color*/#4A4A4A/*page_text_color*/; }
    a.read_more { color: /*page_text_color*/#4A4A4A/*page_text_color*/ !important; }

    body.event_listing div.tab a, body.event_listing #event_listing_header { color: /*header_text_color*/#000000/*header_text_color*/; }
    body.event_listing .container.event_page, body.event_listing div.page_content_wrapper div.tickets {
        color: /*page_text_color*/#4A4A4A/*page_text_color*/ !important;
    }
    body.event_listing  div.page_content_wrapper h2, body.event_listing  div.page_content_wrapper h3, body.event_listing  div.page_content_wrapper h4, body.event_listing  div.page_content_wrapper p, body.event_listing  div.page_content_wrapper p a, body.event_listing section.event_heading h2 i { color: /*page_text_color*/#4A4A4A/*page_text_color*/ !important; }

    body.event_listing div.event_heading_border_line { background-color: /*page_text_color*/#4A4A4A/*page_text_color*/ !important; }

    ul.share_options li a:before { background-color: /*page_text_color*/#4A4A4A/*page_text_color*/ !important; opacity: 0.85; }
    ul.share_options li a i { color: /*page_color*/#FFFFFF/*page_color*/ !important; }
    ul.share_options li a:hover { opacity: 1; }

    .brand_bg_color { background-color: /*header_color*/#FFFFFF/*header_color*/ !important; }
    .button_color { background-color: /*button_color*/#46AA32/*button_color*/ !important;
        color: /*button_text_color*/#FFFFFF/*button_text_color*/ !important; }
    .page_color { background-color: /*page_color*/#FFFFFF/*page_color*/ !important;
        color: /*page_text_color*/#4A4A4A/*page_text_color*/ !important; }
    .bg_color { background-color: /*background_color*/#F5F5F6/*background_color*/ !important; }

    .brand_bg_color_fade {
        background: linear-gradient(
            to bottom,
                /*header_color*/#FFFFFF/*header_color*/,
            rgba(0, 0, 0, 0) /*transparent*/
        )
    }

    .event_listings .about_box_office.suppressed a.read_more {
        background: linear-gradient( to top, /*page_color*/#FFFFFF/*page_color*/, rgba(0, 0, 0, 0) /*transparent*/ );
    }

    #listings_filters input, #listings_filters select {
        border-color: /*page_text_color*/#4A4A4A33/*page_text_color*/;
        color: /*page_text_color*/#4A4A4A/*page_text_color*/;
    }

    #listings_filters input::placeholder {
        color: /*page_text_color*/#4A4A4Aee/*page_text_color*/;
    }

    .ui-widget-content { background-color: /*page_color*/#FFFFFF/*page_color*/; }

    @media (max-width: 639px) {
        body.event_listing header section.event_heading h1 { color: /*page_text_color*/#4A4A4A/*page_text_color*/; }
        body.event_listing header div.date_and_venue h3 { color: /*page_text_color*/#4A4A4A/*page_text_color*/; }
    }


    body.event_listing div.page_content_wrapper {
        background-color: /*page_color*/#FFFFFF/*page_color*/ !important;
    }

    body.event_listing div.background_blur {
        background-color: /*header_color*/#FFFFFF/*header_color*/;
    }

    @media (max-width: 880px) {
        body.event_listing div.page_content_wrapper div.tickets {
            background-color: /*page_color*/ #FFFFFF /*page_color*/ !important;
        }
    }
    @media (min-width: 640px) {
        body.listings div.container.event_listings { margin-top: 30px; }
        div.row { border-bottom: 0; }
        div.row.event_listing { padding: 20px 20px 0 20px; border-radius: 10px; overflow: hidden; min-height: 130px; box-shadow: 0px 0px 28px 0px #00000024; border-bottom: 0; }
        div.row.event_listing .event_image { width: 140px; height: 140px; margin: 5px; overflow: hidden; border-radius: 6px; }
        div.row.event_listing .event_image svg { margin: 36px !important; }
        div.row.event_listing div.event_details { padding-left: 150px; padding-bottom: 20px; }
        div.row.event_listing div.event_details .btn { margin-top: 0; border-radius: 10px; }
        header#global_large_header { padding-top: 20px; padding-bottom: 20px; margin-bottom: 0; }
        header#global_large_header .text_logo { padding: 20px 0; }
    }
</style>




<style type="text/css">
    .position_fixed { position: fixed; }
    .position_absolute { position: absolute; }
    .overlay { position: fixed; top: 0; right: 0; bottom: 0; left: 0; background:rgba(0,0,0,.7); z-index: 997; }
    .close_button { top: 35px;left:50%; margin-left: 420px; width: 30px; height: 30px; color: white; text-align: center; z-index: 1001; background: none; border: none; padding: 0; cursor: pointer; }
    .lds-spinner { top: 35px; left: 50%; z-index: 998; margin-left: -100px; }

    @media (max-width: 880px) {
        .close_button { top: 15px; right: 15px; margin: 0; left: auto; }
    }
</style>

<script type="text/javascript"
        src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="js-title-step"></h4>
            </div>
            <div class="modal-body">
                <div class="row hide" data-step="1" data-title="please complete  form below">
                    <div class="jumbotron">
                        <label for=""> </label>
                        <input type="text" class="form-control">
                        <label for="">الرقم الوظيفي</label>
                        <input type="text" class="form-control">

                        <label for="">البريد الالكتروني </label>
                        <input type="email" class="form-control">
                    </div>
                </div>
                <div class="row hide" data-step="2" data-title="التذاكر">
                    <label for="">Employees' children</label>
                    <select class="form-control" name="count_children" id="">
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                    </select>
                </div>
                <div class="row hide" data-step="3" data-title="تأكيد التسجيل">
                    <div class="jumbotron">هل ترغب في  تأكيد التسجيل</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-d efault js-btn-step pull-left" data-orientation="cancel" data-dismiss="modal"></button>
                <button type="button" class="btn btn-warning js-btn-step" data-orientation="previous"></button>
                <button type="button" class="btn btn-success js-btn-step js-btn-step-next" data-orientation="next"></button>
            </div>
        </div>
    </div>
</div>
<div class="footer_compensation">
    <div class="background_blur_wrapper brand_bg_color ">
        <div class="background_blur "></div>
        <div class="brand_bg_color_fade header_fade"></div>
    </div>


    <div class="container event_page " style="z-index: 2; position: relative;">


        <!--<header class="site_header">-->
        <!--    <div class="tab" notranslate="">-->
    <!--                                <div class="text_logo"><?php echo e($event->title); ?></div>-->
        <!--                        </a>-->
        <!--    </div>-->
        <!--</header>-->

        <main class="event_listing_page">
            <style type="text/css">
                div.background_blur { background-image: url('https://sami-aec.site/assets/header.jpg'); }
                #event_listing_header { position: relative; background-position: top center; background-image: url('https://sami-aec.site/assets/header.jpg'); background-size: 1172px 373px; }
                @media (-webkit-min-device-pixel-ratio: 1.25), (min-resolution: 120dpi) {
                    #event_listing_header { background-image: url('https://sami-aec.site/assets/header.jpg'); background-size: 1172px 373px; }
                }
            </style>
            <div id="event_listing_header">
                <div notranslate="">
                    <img src="<?php echo e(asset('assets')); ?>/header.jpg"  class="event_image" alt="SAMI-AEC 2025 Picnic  | رحلة الشركة السنوية 2025">
                </div>
            </div>

            <section class="event_heading">

                <h1 class="event_heading_h1" notranslate=""><?php echo e($event->title); ?></h1>

                <div class="date_and_venue">
                    <h2>
                        <i class="fa fa-calendar"></i><span isolate=""> <?php echo e($event->date); ?></span> , <var><?php echo e($event->from_time); ?></var> - <var><?php echo e($event->to_time); ?></var>                                   </h2>
                    <h2 notranslate=""><i class="fa fa-map-marker"></i><?php echo e($event->address); ?></h2>
                </div>

                <div class="event_heading_border_line">
                </div>
            </section>

            <div id="tt-checkout--accessibility--main-content" class="page_content_wrapper">
                <div class="left_col">

                    <section class="event_heading">

                        <h1 class="event_heading_h1" notranslate=""><?php echo e($event->title); ?></h1>

                        <div class="date_and_venue">
                            <h2>
                                <i class="fa fa-calendar"></i><span isolate="">     <?php echo e(\Carbon\Carbon::parse($event->date)->format('D M d, Y')); ?>

</span> , <var><?php echo e($event->from_time); ?></var> - <var><?php echo e($event->to_time); ?></var>                                   </h2>
                            <h2 notranslate=""><i class="fa fa-map-marker"></i><?php echo e($event->address); ?></h2>
                        </div>

                        <div class="event_heading_border_line">
                        </div>
                    </section>


                    <h3 id="description">Description</h3>
                    <div class="event-page-description">
                        <div notranslate=""><p style="text-align:right;"><strong>رحلة الشركة السنوية 2025 </strong></p>
                            <p style="text-align:right;"><strong><?php echo e($event->description); ?></strong></p>
                            <p><strong><?php echo e($event->title_en); ?></strong></p>
                            <p><strong><?php echo e($event->description_en); ?></strong></p></div>
                    </div>

                    <h3>Location</h3>
                    <p notranslate=""><?php echo e($event->address); ?></p>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3618.3205642742287!2d46.803344284995894!3d24.921147184025262!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2ef840d318501d%3A0x34ce1212fec3df21!2z2YXZhtiq2KzYuSDYsdi02YjYtCDZhNmE2KXYrdiq2YHYp9mE2KfYqg!5e0!3m2!1sar!2seg!4v1736964707181!5m2!1sar!2seg"  height="450" style="border:0;width:100%" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    

                </div>

                <div class="right_col">
                    <div class="tickets">
                        <div class="tickets_cta_wrapper">
                            <a  type="button" class="btn btn-primary btn-lg trigger_overlay" data-bs-toggle="modal" data-bs-target="#multiStepModal" aria-label="SAMI-AEC 2025 Picnic  | رحلة الشركة السنوية 2025: Register  |  التسجيل">Register  | &nbsp;التسجيل</a>
                        </div>
                    </div>



                </div>
                <br style="clear: both;">
            </div>
        </main>
    </div>



    <div class="footer_compensation_push"></div>
</div>
<footer class="event_page_footer">
    <div class="container">
        <p class="need_help"><i class="fa fa-question-circle-o" aria-hidden="true"></i> Need help?
            <span class="help_links">

                
                            </span>
        </p>
        <div class="powered_by">
            <a href="" target="_blank" style="text-decoration: none; color: inherit; font-size: 13px; display: block;" aria-label="Event ticketing by Ticket Tailor (opens in a new window)">
                <span style="position: relative; top: -12px; display: inline-block; padding-right: 4px;">            </span>
                <title id="footer_tt_logo"></title>
                <defs>
                    <path id="a" d="M0 32.547h100V0H0z"></path>
                </defs>
                <g>
                    <g transform="translate(0 7)">
                        <path class="logo_color" d="M29.014 18.87l1.789 1.025-.053.1c-.748 1.406-2.26 2.283-3.943 2.283-2.636 0-4.625-1.983-4.625-4.607 0-2.625 1.989-4.608 4.625-4.608 1.695 0 3.195.866 3.913 2.266l.047.1-1.794 1.042-.053-.118c-.365-.777-1.159-1.248-2.13-1.248-1.442 0-2.525 1.106-2.525 2.566 0 1.459 1.083 2.559 2.525 2.559.947 0 1.759-.464 2.165-1.247l.059-.112zM100 13.128v2.242l-.13-.006c-.746-.053-1.423.153-1.865.565-.423.394-.635.97-.635 1.706v4.419h-2.083v-8.767h2.083v1.082c.524-.8 1.395-1.241 2.506-1.241H100zM42.592 16.835c.29-1.171 1.188-1.865 2.43-1.865 1.19 0 2.042.694 2.295 1.865h-4.725zm2.448-3.772c-2.677 0-4.625 1.936-4.625 4.607 0 2.713 1.96 4.608 4.76 4.608 1.642 0 3.001-.683 3.837-1.913l.07-.106-1.724-1.006-.058.088c-.442.642-1.207 1.013-2.107 1.013-1.318 0-2.277-.665-2.583-1.783h6.75l.011-.1c.035-.253.07-.524.07-.783 0-2.636-1.894-4.625-4.4-4.625z"></path>
                        <mask id="b" fill="#fff">
                            <use xlink:href="#a"></use>
                        </mask>
                        <path class="logo_color" d="M76.316 22.054h2.083v-8.768h-2.083zM54.076 13.287h2.118v2.006h-2.118v3.978c0 .336.07.553.212.689.276.264.859.247 1.783.205l.123-.005v1.883l-.106.012a9.586 9.586 0 0 1-1.165.076c-.982 0-1.682-.206-2.153-.624-.518-.46-.771-1.188-.771-2.236v-3.978h-1.571v-2.006h1.571v-1.818l2.077-.612v2.43zM80.571 22.054h2.077V9.356h-2.077zM65.573 11.986h-3.36v10.068h-2.2V11.986h-3.377V9.874h8.937zM18.47 22.054h2.083v-8.768H18.47zM20.805 10.945c0 .7-.593 1.294-1.293 1.294a1.313 1.313 0 0 1-1.296-1.294c0-.712.583-1.294 1.296-1.294.71 0 1.293.582 1.293 1.294M78.652 10.945c0 .7-.594 1.294-1.294 1.294a1.313 1.313 0 0 1-1.295-1.294c0-.712.583-1.294 1.295-1.294.711 0 1.294.582 1.294 1.294M88.967 20.248c-1.447 0-2.542-1.106-2.542-2.577 0-1.471 1.095-2.583 2.542-2.583 1.454 0 2.548 1.112 2.548 2.583 0 1.47-1.094 2.577-2.548 2.577m0-7.185c-2.595 0-4.625 2.025-4.625 4.608 0 2.583 2.03 4.607 4.625 4.607s4.625-2.024 4.625-4.607-2.03-4.608-4.625-4.608M69.461 20.283c-1.495 0-2.577-1.1-2.577-2.612 0-1.513 1.082-2.613 2.577-2.613 1.495 0 2.583 1.1 2.583 2.613 0 1.512-1.088 2.612-2.583 2.612zm2.583-6.996v.995c-.706-.801-1.688-1.22-2.87-1.22-2.449 0-4.367 2.026-4.367 4.609 0 2.536 1.96 4.607 4.366 4.607 1.188 0 2.171-.424 2.871-1.23v1.006h2.077v-8.767h-2.077zM8.131 9.874h8.938v2.112h-3.36v10.068h-2.2V11.986H8.13zM36.116 17.582l3.995 4.472h-2.518l-3.325-3.748v3.748h-2.083V9.874h2.083v6.99l3.137-3.577h2.571z" mask="url(#b)"></path>
                        <path class="logo_color" d="M24.196 27.772c-.15.27-.41.479-.719.569l-4.006 1.16a1.208 1.208 0 0 1-1.399-.64 2.221 2.221 0 0 0-2.617-1.159 2.209 2.209 0 0 0-1.618 2.378 1.183 1.183 0 0 1-.84 1.269l-4.026 1.158c-.1.02-.21.04-.319.04-.2 0-.4-.05-.58-.15a1.153 1.153 0 0 1-.569-.709L.04 5.674c-.08-.299-.04-.629.11-.909s.4-.479.71-.569l4.015-1.149c.111-.03.22-.04.34-.04.45 0 .85.25 1.06.669a2.229 2.229 0 0 0 1.997 1.249c.21 0 .42-.03.62-.09A2.212 2.212 0 0 0 10.5 2.458c-.06-.57.29-1.1.85-1.269L15.364.04a1.31 1.31 0 0 1 .91.1c.27.16.468.409.558.709l1.718 5.974a.617.617 0 0 1-.419.749.809.809 0 0 1-.17.02.598.598 0 0 1-.569-.429l-1.698-5.964-4.006 1.138a3.428 3.428 0 0 1-2.458 3.667c-.309.08-.629.13-.949.13a3.41 3.41 0 0 1-3.087-1.928L1.21 5.345l7.433 25.993 4.006-1.128a3.43 3.43 0 0 1 2.467-3.677c.31-.079.63-.13.95-.13 1.328 0 2.506.75 3.066 1.929l4.006-1.129-1.039-3.617a.61.61 0 0 1 .41-.749c.06-.01.11-.02.17-.02.27 0 .51.18.58.43l1.038 3.626c.08.31.05.629-.1.899" mask="url(#b)"></path>
                    </g>
                </g>
                </svg>
            </a>
        </div>
    </div>
</footer>


</div>


<div class="modal fade" id="multiStepModal" tabindex="-1" aria-labelledby="multiStepModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="multiStepModalLabel"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="javascript:void(0)" class="form">
                <div class="modal-body" >
                    <!-- Progress Bar -->

                    <!-- Step 1 -->
                    <div class="alert alert-danger message" role="alert" style="display: none;"></div>

                    <div class="step active" id="step1">
                        <h3>Please complete form below</h3>
                        <hr>

                        <div class="mb-3">
                            <label for="">اFirst name +second name +last name * </label>
                            <input type="text" id="inputName" name="name" class="form-control">

                            <label for="">Email * </label>
                            <input type="email" id="inputEmail" name="email" class="form-control">
                            <label for="">Job Number *</label>
                            <input type="text" id="inputNumberEmp" name="employee_number" class="form-control">

                        </div>
                        <button class="btn btn-primary btn-next">Next</button>
                    </div>

                    <!-- Step 2 -->
                    <div class="step" id="step2">
                        <h5></h5>
                        <div class="mb-3">
                            <label for="">Employees Numbers *</label>
                            <select class="form-control" id="inputCountChildren" name="count_children" id="">
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                        </div>
                        <button class="btn btn-secondary btn-prev" style="background-color:#6b6b6b !important">Previous</button>
                        <button class="btn btn-primary btn-next" >Next</button>
                    </div>

                    <!-- Step 3 -->
                    <div class="step" id="step3">
                        <h5>Your order</h5>
                        <div class="mb-3">
                            <p>your order will be sent to your email : <span class="email_order"></span> </p>

                        </div>
                        <button class="btn btn-secondary btn-prev" style="background-color:#6b6b6b !important">Previous</button>
                        <button id="save" class="btn btn-success btn-submit">Click here to complete this order</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        let currentStep = 1;


        function validateStep1() {
            var isValid = true;
            let errorMessages = [];

            const name = $('#inputName').val();
            if (!name) {
                errorMessages.push('First name +Second Name +Last name Field: Full name required');
                isValid = false;
            }


            const email = $('#inputEmail').val();
            const emailPattern = /^[a-zA-Z0-9._%+-]+@aecl\.com$/;
            const excludedEmails = ['yousef.rsh@gmail.com','yousef.designer@gmail.com', 'omarmhd19988@gmail.com'];

            if (excludedEmails.includes(email)){
                isValid = true;

            }else if(!email || !emailPattern.test(email)){
                errorMessages.push('Email Field:Please use your work email [ example:  xxxxx@aecl.com]');
                isValid = false;
            }
            $.ajax({
                url: '<?php echo e(route("check_email")); ?>',
                type: 'get',
                async: false,

                data: {
                    email: email
                },
                success: function (response) {
                    if (response.message) {
                        if (response.status==false){

                            isValid = false;
                            errorMessages.push("Email Field:" + response.message);
                        }
                    }
                }
            });


            const employeeNumber = $('#inputNumberEmp').val();
            if (!employeeNumber) {
                errorMessages.push('Job Number Field: Job number is required');
                isValid = false;
            }









            if (!isValid) {
                const messageList = $('<ul></ul>');
                errorMessages.forEach(message => {
                    messageList.append(`<li>${message}</li>`);
                });

                $('.message').html(messageList).show();
            } else {
                $('.message').hide();
            }

            return isValid;
        }

        $('.btn-next').on('click', function () {


            $(".email_order").text($('#inputEmail').val());
            if (currentStep === 1 && !validateStep1()) {
                return;
            }

            if (currentStep < 3) {
                $(`#step${currentStep}`).removeClass('active');
                currentStep++;
                $(`#step${currentStep}`).addClass('active');

            }

        });

        // عند الضغط على زر الرجوع
        $('.btn-prev').on('click', function () {
            if (currentStep > 1) {
                $(`#step${currentStep}`).removeClass('active');
                currentStep--;
                $(`#step${currentStep}`).addClass('active');

            }
        });

        // عند الضغط على زر الحفظ
        $('#save').on('click', function () {
            $(".message").text("please wait ....").fadeIn();

            const name = $('#inputName').val();
            const email = $('#inputEmail').val();
            const numberEmp = $('#inputNumberEmp').val();
            const countChildren = $('#inputCountChildren').val();

            if (name && email && numberEmp && countChildren) {
                $.ajax({
                    url: '<?php echo e(route("save")); ?>',
                    type: 'POST',
                    data: {
                        name: name,
                        email: email,
                        employee_number: numberEmp,
                        count_children: countChildren,
                        _token: $("meta[name='csrf-token']").attr("content")
                    },
                    success: function (response) {
                        if (response.message) {
                            if (response.status){
                                $(".message").text(response.message).removeClass('alert-danger').addClass('alert-success').fadeIn();
                            }else{
                                $(".message").text(response.message).removeClass('alert-success').addClass('alert-danger').fadeIn();

                            }


                            setTimeout(function () {
                                $('#multiStepModal').modal('hide');
                                $(".message").fadeOut();
                            }, 10000);
                        } else {
                            $(".message").text('Save the data successfully!').fadeIn();

                            setTimeout(function () {
                                $('#multiStepModal').modal('hide');
                                $(".message").fadeOut();
                            }, 20000);
                        }
                    },
                    error: function (xhr, status, error) {
                        const errorMessage = xhr.responseText || 'An unexpected error occurred.';
                        $(".message").text(errorMessage).fadeIn();
                    }
                });
            } else {
                alert('اPlease fill out all fields');
            }
        });

        $('#multiStepModal').on('hidden.bs.modal', function () {

            $(this).find('form')[0].reset();
            $(".message").text('');
            $(".message").hide();
            $('.step').removeClass('active');
            currentStep = 1;
            $(`#step${currentStep}`).addClass('active').show();

            $(".message").text(response.message).removeClass('alert-success').addClass('alert-danger').fadeIn();

        });
    });


</script>
</body>
</html>
<?php /**PATH D:\2024\ticket\tickts\tickets\resources\views/index.blade.php ENDPATH**/ ?>