<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text-center mb-4">
        <h1 class="page-title">
            <i class="fas fa-cogs"></i> Dashboard
        </h1>
    </div>

    <div class="row g-3">
        <!-- Register Attendance and Scan with Scanner -->
        <div class="col-12 col-md-6">
            <a href="<?php echo e(route('register_attendance')); ?>" class="btn btn-primary btn-custom w-100">
                <i class="fas fa-user-check"></i> Register Attendance
            </a>
        </div>
        <div class="col-12 col-md-6">
            <a href="<?php echo e(route('qr')); ?>" class="btn btn-secondary btn-custom w-100">
                <i class="fas fa-qrcode"></i> Scan with Scanner
            </a>
        </div>

        <!-- Attendance List and Statistics -->
        <div class="col-12 col-md-6">
            <a href="<?php echo e(route('attendance_list')); ?>" class="btn btn-success btn-custom w-100">
                <i class="fas fa-list"></i> Attendance List
            </a>
        </div>
        <div class="col-12 col-md-6">
            <a href="<?php echo e(route('statistics')); ?>" class="btn btn-warning btn-custom w-100">
                <i class="fas fa-chart-bar"></i> Statistics
            </a>
        </div>

        <!-- Log Out -->
        <div class="col-12">
            <form action="<?php echo e(route('logout')); ?>" method="POST" class="w-100">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger w-100">
                    <i class="fas fa-sign-out-alt"></i> Log Out
                </button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2024\ticket\tickts\tickets\resources\views/admin/index.blade.php ENDPATH**/ ?>