

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text-left mb-4 d-flex justify-content-between align-items-center">
        <h1 class="page-title">
            <i class="fas fa-user-check"></i> Register Attendance
        </h1>
        <a href="<?php echo e(route('dashboard.index')); ?>" class="btn btn-secondary">
            <i class="fas fa-home"></i>
        </a>
    </div>

    <div class="container my-4">
        <!-- Search Form -->
        <form action="<?php echo e(route('search_on_ticket')); ?>" method="get">
            <div class="mb-3 d-flex align-items-center">
                <input
                    type="text"
                    id="searchInput"
                    name="searchInput"
                    placeholder="Search by name, email, job number, or ticket..."
                    class="form-control me-2 shadow-sm"
                    style="border-radius: 10px;"
                />
                <button type="submit" id="searchBtn" class="btn btn-primary shadow-sm">
                    <i class="fas fa-search"></i>
                </button>
                <a href="/export" title="export excel" type="submit" id="searchBtn" class="btn btn-success shadow-sm" style="margin-left: 3px">
                    <i class="fas fa-file-excel"></i>
                </a>
            </div>
        </form>

        <!-- Responsive Table -->
        <div class="table-responsive shadow-sm" style="border-radius: 10px; overflow-x: auto;">
            <table class="table table-bordered table-hover">
                <thead class="table-light">
                <tr>
                    <th># Ticket</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Type</th>
                    <th>Checked in at</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody id="tableBody">
                <?php if(empty($tickets)): ?>
               <tr>
                   <th colspan="6" class="text-center">
                       No results found. .
                   </th>
               </tr>
                <?php endif; ?>
                <?php if(isset($tickets)): ?>
                    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="# Ticket"><?php echo e($ticket->id); ?></td>
                            <td data-label="Name"><?php echo e($ticket->employee_name); ?></td>
                            <td data-label="Email"><?php echo e($ticket->employee_email); ?></td>
                            <td data-label="Type"><?php echo e($ticket->is_children == 'no' ? 'Employee' : 'Child'); ?></td>
                            <td data-label="Checked in at"><?php echo e($ticket->checked_in_at); ?></td>
                            <td data-label="Actions">
                                <a href="<?php echo e(route("checked_in",$ticket->id)); ?>" class="btn btn-info btn-sm">Register<i class="fas fa-check"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <style>
        /* General Page Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        .container {
            background-color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        h1.page-title {
            font-size: 1.5rem;
            color: #333;
        }

        /* Table Styling */
        .table {
            border-collapse: collapse;
            width: 100%;
        }

        .table th, .table td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        .table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }

        .table tbody tr:hover {
            background-color: #f1f1f1;
        }

        /* Responsive Table for Mobile */
        @media (max-width: 768px) {
            .table thead {
                display: none; /* Hide the header */
            }

            .table tbody tr {
                display: block;
                margin-bottom: 15px;
                border: 1px solid #ddd;
                border-radius: 10px;
                background-color: #fff;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                padding: 10px;
            }

            .table tbody td {
                display: flex;
                justify-content: space-between;
                padding: 8px 10px;
                font-size: 0.9rem;
            }

            .table tbody td::before {
                content: attr(data-label);
                font-weight: bold;
                color: #555;
            }

            .table tbody td:last-child {
                text-align: center;
            }
        }

        /* Buttons Styling */
        .btn {
            border-radius: 5px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }

        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }

        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/samiwsfh/public_html/resources/views/admin/register_attendance.blade.php ENDPATH**/ ?>